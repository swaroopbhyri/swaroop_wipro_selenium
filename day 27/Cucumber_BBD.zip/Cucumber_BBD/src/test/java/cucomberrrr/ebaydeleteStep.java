package cucomberrrr;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class ebaydeleteStep {
	WebDriver driver;

@Given("an item is added to cart")
public void an_item_is_added_to_cart() {
	driver = new ChromeDriver();
    driver.get("https://www.ebay.com/");
    driver.manage().window().maximize();
    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
}

@When("click on cart and delete item")
public void click_on_cart_and_delete_item() {
	eBay_pageclass pg = new eBay_pageclass(driver);
	pg.deletecart();
}

@Then("delted from cart")
public void delted_from_cart() {
    driver.close();
    System.out.println("deleted sucessfully");
}



}
