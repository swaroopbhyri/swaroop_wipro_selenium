package cucomberrrr;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class eBay_pageclass {
	WebDriver driver;
	
	By email= By.id("userid");
	By passw = By.id("pass");
	By cont= By.id("signin-continue-btn");
	By submit = By.id("sgnBt");
	By searchh = By.id("gh-ac");
	By item = By.xpath("//*[@id=\"item1d909ffc3d\"]/div/div[1]/div/a/div/img");
	By adtocart = By.id("atcBtn_btn_1");
	By ctlogo = By.cssSelector("span[class=\"gh-cart__icon\"]");
	By dlt= By.cssSelector("button[data-test-id=\"cart-remove-item\"]");
	By logo = By.id("gh-logo");
	By act= By.cssSelector("div>button[class=\"gh-flyout__target gh-flyout__target--left\"]");
	By actst = By.id("account-settings-link-PI");
	By changeuser= By.id("individual_username_edit_button");
	By usubmit = By.id("username_submit_edit_btn");
	
	public eBay_pageclass(WebDriver driver) {
		this.driver=driver;
	}
	
	public void username() {
		 WebElement login=driver.findElement(By.xpath("//*[@id=\"gh\"]/nav/div[1]/span[1]/span/a"));
		  login.click();
		 
		  WebElement username=driver.findElement(email);
		  username.sendKeys("swaroopbhyri1143@gmail.com");
		  username.sendKeys(Keys.ENTER);
		  driver.findElement(cont).click();
			 WebElement pass = driver.findElement(passw);
			  pass.sendKeys("Swaroop@2706");
			  pass.sendKeys(Keys.ENTER);
			  //driver.findElement(By.id("sgnBt")).click();
			  
		
	}
	
	public void multipltvalue() {
		driver.findElement(logo).click();
		 WebElement search= driver.findElement(searchh);
		  String[] searches= {"watch","phone","laptop"};
		  for(String s:searches) {
			  search.sendKeys(s);
			  search.sendKeys(Keys.ENTER);
			  search=driver.findElement(By.id("gh-ac"));
			  search.clear();
			   
		  } 
	
	}
	public void singleitem() throws InterruptedException {
		 WebElement login=driver.findElement(By.xpath("//*[@id=\"gh\"]/nav/div[1]/span[1]/span/a"));
		  login.click();
		 
		  WebElement username=driver.findElement(email);
		  username.sendKeys("swaroopbhyri1143@gmail.com");
		  username.sendKeys(Keys.ENTER);
		  driver.findElement(cont).click();
			 WebElement pass = driver.findElement(passw);
			  pass.sendKeys("Swaroop@2706");
			  pass.sendKeys(Keys.ENTER);
		 WebElement search= driver.findElement(searchh);
		  search.sendKeys("headset wireless");
		  search.sendKeys(Keys.ENTER);
//		  WebElement addtocartlogo=  driver.findElement(item);
//			addtocartlogo.click();

		  driver.get("https://www.ebay.com/itm/126980455485?_skw=headset+wireless&epid=9040583376&itmmeta=01K35DVVJJCA6RA9H1GJHBCJK9&hash=item1d909ffc3d:g:rlEAAOSwqC5nyya6&itmprp=enc%3AAQAKAAAA8FkggFvd1GGDu0w3yXCmi1dqC0MHEUJaxYkBn%2BjHzvP%2FzKa6tsZXbJHzPyR9shyoP56VoU6pLWCdHUdwtQH2u53zUpWDl1Ggt5NNTpoTb2YuWkEl2%2FimpRyXE353Mm42eWXXgkJiT8L2hsYab2GLVZ2To8ITRIO9L0u1g8i9B1l5vOpQyo6EqKD%2BSFNL2%2FXjoXRLb%2BwLpk%2BijxXmj3WDOWKk%2FXGkz%2BLFnQ89NP2KxgPevCfIxynHuHdesghXUV0ztsKc6emGjQuQCJNdIrxVEpFcYU2Yb28R7ulcrwDAiKclqp5CPL%2BWBUMOkRdaJ7NUmw%3D%3D%7Ctkp%3ABFBMvLnvrZlm");
//			ArrayList<String> tabs = new ArrayList<>(driver.getWindowHandles());
//			  driver.switchTo().window(tabs.get(1));
			  
			  JavascriptExecutor jse= (JavascriptExecutor)driver;
			  jse.executeScript("window.scrollBy(0,400)");
			driver.findElement(adtocart).click();
			Thread.sleep(3000);
			
			driver.findElement(By.cssSelector("div>button[aria-label=\"Close overlay\"]")).click();
			Thread.sleep(3000);
			 WebElement cart=driver.findElement(By.cssSelector("span[class=\"gh-cart__icon\"]"));
			  cart.click();
			  
			  
			  WebElement delete=driver.findElement(By.cssSelector("button[data-test-id=\"cart-remove-item\"]"));
			  delete.click();
	}
	
	
	
	
	public void  deletecart() {
		 
		 WebElement cart=driver.findElement(By.cssSelector("span[class=\"gh-cart__icon\"]"));
		  cart.click();
		  
		  
		  WebElement delete=driver.findElement(By.cssSelector("button[data-test-id=\"cart-remove-item\"]"));
		  delete.click();
	}
	
	public void act() {
		driver.findElement(logo).click();
		WebElement cart=driver.findElement(act);
		  Actions act=new Actions(driver);
		  act.moveToElement(cart).perform();
	}
	
	public void changeusername() {
		 WebElement login=driver.findElement(By.xpath("//*[@id=\"gh\"]/nav/div[1]/span[1]/span/a"));
		  login.click();
//		  driver.get("https://accountsettings.ebay.com/uas");
		  
		  WebElement username=driver.findElement(email);
		  username.sendKeys("swaroopbhyri1143@gmail.com");
		  username.sendKeys(Keys.ENTER);
		  driver.findElement(cont).click();
			 WebElement pass = driver.findElement(passw);
			  pass.sendKeys("Swaroop@2706");
			  pass.sendKeys(Keys.ENTER);
		driver.get("https://accountsettings.ebay.com/uas");
		 driver.findElement(By.id("account-settings-link-PI")).click();
//		driver.findElement(actst).click();
//		 driver.findElement(changeuser).click();
//		  WebElement username1=driver.findElement(By.id("user_name"));
//		  username1.clear();
//		  username1.sendKeys("Swaroop1234");
//		  username1.sendKeys(Keys.ENTER);
//			driver.findElement(usubmit).click();
	}
	
	public void changeaddressbtn() throws InterruptedException {
		
//		WebElement login=driver.findElement(By.xpath("//*[@id=\"gh\"]/nav/div[1]/span[1]/span/a"));
//		  login.click();
//		  WebElement username=driver.findElement(email);
//		  username.sendKeys("swaroopbhyri1143@gmail.com");
//		  username.sendKeys(Keys.ENTER);
//		  driver.findElement(cont).click();
//			 WebElement pass = driver.findElement(passw);
//			  pass.sendKeys("Swaroop@2706");
//			  pass.sendKeys(Keys.ENTER);
//				    // Go to eBay home
				    driver.findElement(By.id("gh-logo")).click();
				    Thread.sleep(2000);

				    // Hover over "Hi Nasir!" menu
				    WebElement hiMsg = driver.findElement(By.cssSelector("span.gh-identity__greeting"));
				    Actions act = new Actions(driver);
				    act.moveToElement(hiMsg).perform();
				    Thread.sleep(2000);

				    
				    driver.get("https://accountsettings.ebay.com/uas");
				    Thread.sleep(3000);

				    driver.findElement(By.id("account-settings-link-PI")).click();
				    Thread.sleep(2000);

				   
				    try {
				        // If email field is visible, fill it in
				        WebElement emailField = driver.findElement(By.id("userid"));
				        if (emailField.isDisplayed()) {
				            emailField.sendKeys("nasirhussainraghav@gmail.com");
				            driver.findElement(By.id("signin-continue-btn")).click();
				            Thread.sleep(1000);
				        }
				    } catch (NoSuchElementException e) {
				        // Email field not present; continue to password
				        System.out.println("Email not asked, continuing to password.");
				    }

				    // Enter password and sign in
				    WebElement passwordField = driver.findElement(By.id("pass"));
				    passwordField.sendKeys("SaiRaghav@1903");
				    driver.findElement(By.id("sgnBt")).click();
				    Thread.sleep(2000);

				    // Click "Edit" on address section
				    driver.findElement(By.id("individual_personal_info_address_edit_button")).click();
				    Thread.sleep(2000);

				    // Update street address
				    WebElement streetAddress = driver.findElement(By.cssSelector("input[aria-label='Street address']"));
				    streetAddress.clear();
				    streetAddress.sendKeys("Saptagiri Nagar,ACamp");
				    Thread.sleep(1000);

				    // Update middle name
				    WebElement m_name = driver.findElement(By.id("middleName"));
				    m_name.clear();
				    m_name.sendKeys("Hussain");
				    Thread.sleep(1000);

				    // Update city
				    WebElement city = driver.findElement(By.id("city"));
				    city.clear();
				    city.sendKeys("kurnool");
				    Thread.sleep(1000);

				    // Update zipcode
				    WebElement zipcode = driver.findElement(By.id("postalCode"));
				    zipcode.clear();
				    zipcode.sendKeys("518002");
				    Thread.sleep(1000);

				    // Submit changes
				    driver.findElement(By.id("address_edit_submit_button")).click();
				    Thread.sleep(2000);
				}
		 

	public void shopbycat() {
		 driver.findElement(By.cssSelector("button[aria-controls=\"s0-1-4-12-0-1-dialog\"]")).click();
		  driver.findElement(By.cssSelector("a[_sp=\"m570.l3410\"]")).click();
		  driver.findElement(By.xpath("/html/body/div[2]/div[2]/section[2]/section/div/ul/li[3]/span/a")).click();
		  driver.findElement(By.xpath("/html/body/div[2]/div[2]/section[1]/div/nav/ul/li[1]/a")).click();
	}
	public void shopbyall() {
		driver.findElement(By.cssSelector("select>option[value=\"12576\"]")).click(); 
		  driver.findElement(By.id("gh-search-btn")).click(); 
		  driver.findElement(By.xpath("/html/body/div[2]/div[2]/section[1]/div/nav/ul/li[1]/a")).click(); 

	}
	public void daily_deals() {
		driver.findElement(logo).click();
		driver.findElement(By.cssSelector("a[_sp=\"m570.l3188\"]")).click();
	}
	public void facebook() {
		driver.findElement(logo).click();
		driver.findElement(By.cssSelector("li>a[_exsp=\"m571.l2942\"]")).click();
		
	}
	public void signout() {
		WebElement login=driver.findElement(By.xpath("//*[@id=\"gh\"]/nav/div[1]/span[1]/span/a"));
		  login.click();
		 
		  WebElement username=driver.findElement(email);
		  username.sendKeys("swaroopbhyri1143@gmail.com");
		  username.sendKeys(Keys.ENTER);
		  driver.findElement(cont).click();
			 WebElement pass = driver.findElement(passw);
			  pass.sendKeys("Swaroop@2706");
			  pass.sendKeys(Keys.ENTER);
		WebElement elementToHover = driver.findElement(By.cssSelector("span>div[class=\"gh-flyout is-left-aligned\"]"));
		  Actions actions = new Actions(driver);
		  actions.moveToElement(elementToHover).build().perform();
		  driver.findElement(By.cssSelector("a[_sp=\"m570.l2622\"]")).click();
	}
	public void help() {
		driver.findElement(logo).click();
		driver.findElement(By.cssSelector("a[aria-label=\"Help & Contact\"]")).click();
		
	}
	public void giftcard() {
		driver.findElement(logo).click();
		driver.findElement(By.cssSelector("a[aria-label=\"Gift Cards\"]")).click();
	}
	
	
}

