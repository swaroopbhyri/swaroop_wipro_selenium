package cucomberrrr;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class helpStep {
	WebDriver driver;

@Given("webbsitee shouldd be openedd")
public void webbsitee_shouldd_be_openedd() {
	driver = new ChromeDriver();
    driver.get("https://www.ebay.com/");
    driver.manage().window().maximize();
    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
    
}

@When("en clck on help btn")
public void en_clck_on_help_btn() {
	eBay_pageclass pg = new eBay_pageclass(driver);
	pg.help();
   
}

@Then("help is opened")
public void help_is_opened() {
	driver.close();
    
}




}
