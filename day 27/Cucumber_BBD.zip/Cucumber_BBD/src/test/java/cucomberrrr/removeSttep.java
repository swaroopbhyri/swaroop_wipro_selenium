package cucomberrrr;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class removeSttep {
	WebDriver driver;
	

@Given("open eBay webbsite in ur dddefault browser")
public void open_e_bay_webbsite_in_ur_dddefault_browser() {
	driver = new ChromeDriver();
    driver.get("https://www.ebay.com/");
    driver.manage().window().maximize();
    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
}

@When("click on delete carrttt")
public void click_on_delete_carrttt() throws InterruptedException {
	eBay_pageclass pg = new eBay_pageclass(driver);
	pg.singleitem();
}

@Then("done removing")
public void done_removing() {
    driver.close();
}




}
