package cucomberrrr;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class ebayChangeadddressStep {
	WebDriver driver ;

@Given("website is opeeeen")
public void website_is_opeeeen() {
	driver = new ChromeDriver();
    driver.get("https://www.ebay.com/");
    driver.manage().window().maximize();
    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
    
}

@When("select on acccount settings")
public void select_on_acccount_settings() throws InterruptedException {
	eBay_pageclass pg = new eBay_pageclass(driver);
	pg.changeaddressbtn();
}

@Then("sucessfully changed")
public void sucessfully_changed() {
    driver.close();
}




}
