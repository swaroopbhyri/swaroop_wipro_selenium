package cucomberrrr;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class giftcardStep {
WebDriver driver;


@Given("webbsitee shouldd beee openedd in browser")
public void webbsitee_shouldd_beee_openedd_in_browser() {
	driver = new ChromeDriver();
    driver.get("https://www.ebay.com/");
    driver.manage().window().maximize();
    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
}

@When("en clck on giftcard btn")
public void en_clck_on_giftcard_btn() {
	eBay_pageclass pg = new eBay_pageclass(driver);
	pg.help();
}

@Then("gift card is opened")
public void gift_card_is_opened() {
   driver.close();
}




}
